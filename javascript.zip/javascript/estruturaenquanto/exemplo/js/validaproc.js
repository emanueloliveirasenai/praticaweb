function validaProc(){
    
    let i=1;
    while(i<=10){
        
        console.log("Passando na estrutura a " + i + "ª vez o valor de i é: " + i);
        i++;
    }
    return false;
}