function validaProc(){

    for(let i = 10; i>0; i--){
        console.log("Passou a "+i+"ª vez e o número é o: "+i);
    }
    return false;


}