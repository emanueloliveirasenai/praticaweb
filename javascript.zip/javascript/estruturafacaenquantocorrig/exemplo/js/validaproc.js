function validaProc()
{
    /*let = declarador de variável*/
    let conta = 1;

    do{
        console.log("Passou a " + conta + "º vez e o valor é " + conta)
        conta +=1;
    } while(conta<=10)

    return false;

}